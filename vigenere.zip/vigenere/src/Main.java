import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("Please, enter phrase.");
        Scanner scan = new Scanner(System.in);
        String my_phrase = scan.nextLine();
        System.out.println("Please, enter key word - only lowercase");
        String key_word = scan.nextLine();
        String coded_word="";
        char[] phrase=my_phrase.toCharArray();
        int phrase_len= phrase.length;
        char[] key = key_word.toCharArray();
        int key_len = key.length;
        int j=0;
        for (int i=0; i<phrase_len; i++){
            int ascii_p = (int) phrase[i];
            int ascii_k = (int) key[j];
            int code=ascii_k-97;
            if (ascii_p>=65 && ascii_p<=90){
                if(ascii_p+code<=90) {
                    ascii_p = ascii_p + code;
                } else {
                    ascii_p=ascii_p+code-26;
                }
            } else if(ascii_p>=97 && ascii_p<=122){
                if(ascii_p+code<=122){
                    ascii_p=ascii_p+code;
                }else{
                    ascii_p=ascii_p+code-26;
                }
            }
            j++;
            if (j>=key_len){
                j=0;
            }
            phrase[i] = (char) ascii_p;
            coded_word = coded_word + Character.toString(phrase[i]);
        }
        System.out.println(my_phrase);
        System.out.println(key_word);
        System.out.println(coded_word);
    }
}
