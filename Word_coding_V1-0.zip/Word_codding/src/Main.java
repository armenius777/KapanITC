public class Main {

    public static void main(String[] args) {

       String Word="Barev HayAstaN";
        // converting our word to char type Array
        char[] Word_char=Word.toCharArray();
        int word_lenght = Word_char.length;
        //System.out.println(word_lenght);
        int z;
       int code_num=3;
       char space=' ';
        //input Alphabet with lowercase
      char[] alpha_low={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
      char[] alpha_up = new char[26];
      char[] Encoded_word = new char[word_lenght];
      int alpha_lenght=alpha_low.length;
      //  System.out.println(alpha_lenght);
      //convert lowercase alphabet to uppercase
      for (int i=0; i<alpha_lenght; i++){
          alpha_up[i]=Character.toUpperCase(alpha_low[i]);
          //System.out.println(alpha_up[i]);
      }

        for (int i=0; i<word_lenght;i++){
            for (int j=0; j<alpha_lenght; j++){
                if(Character.isUpperCase(Word_char[i])){
                    if (Word_char[i]==alpha_up[j]){
                        z=j+code_num;
                        if (z>alpha_lenght){
                            z=z-alpha_lenght-1;
                        }
                        Encoded_word[i] = alpha_up[z];
                    }
                } else if(Word_char[i]==alpha_low[j]){
                    z=j+code_num;
                    if (z>alpha_lenght){
                        z=z-alpha_lenght-1;
                    }
                    Encoded_word[i] = alpha_low[z];
                } else if (Word_char[i] == space){
                    Encoded_word[i] = space;
                }
            }
        }
        String Code_word = new String(Encoded_word);
        System.out.println(Code_word);

}
}
