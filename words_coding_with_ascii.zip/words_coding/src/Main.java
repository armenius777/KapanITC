public class Main {

    public static void main(String[] args) {

        String input_word = "Barev Mane jan";
        int code = 3;
        String coded_word="";
        char[] Word_char=input_word.toCharArray();
        int word_lenght = Word_char.length;
        for (int i=0; i<word_lenght; i++){
            int ascii = (int) Word_char[i];
            if((ascii>=65) && (ascii<=90)) {
                if (ascii+code>90){
                    ascii=64+code;
                } else {
                    ascii=ascii+code;
                }
            } else if ((ascii>=97) && (ascii<=122)){
                if (ascii+code>122){
                    ascii=96+code;
                } else {
                    ascii=ascii+code;
                }
            }
            Word_char[i] = (char) ascii;
            coded_word = coded_word + Character.toString(Word_char[i]);
        }

        System.out.println(coded_word);

     //   char character = 'A'; // This gives the character 'a'
     //   int ascii = (int) character; // ascii is now 97.
     //   System.out.println(ascii);
    }
}
