public class Main {

    public static void main(String[] args) {
        int sum1=0;
        int sum2=0;
        long number = 5610591081018250L;
        int[]digits = Long.toString(number).chars().map(c -> c-'0').toArray();
        int len = digits.length;
        for (int i=len-2; i>=0; i--){
            if(2*digits[i]<10){
                sum1=sum1+(2*digits[i]);
            } else {
                int j=2*digits[i]/10;
                sum1=sum1+j+(2*digits[i]%10);
            }
            i--;
        }
        for (int i=len-1; i>=0; i--){
            sum2=sum2+digits[i];
            i--;
        }
        sum2=sum2+sum1;
        if (sum2%10 == 0){
            System.out.println("Your card number is valid!");
        } else {
            System.out.println("ATTENTION! Your card is INVALID!");
        }

    }
}
